export default function TimeOfDay(){
    return(
        "G'day Mate"
    )
}